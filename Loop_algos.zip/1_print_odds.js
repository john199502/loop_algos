for (var j = 1; j <=20; j+=2){
    console.log(j);
}
//Print out only odd numbers from 1 to 20
//The expected output will be 1, 3, 5, 7, 9, 11, 13, 15, 17, 19

//YOUR CODE HERE
