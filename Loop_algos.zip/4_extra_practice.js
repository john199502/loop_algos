// Take your previous solutions and write them using the other kind of loop.  
// I.E.  If you wrote both of your algorithms using for loops, now write them out with while loops

while(j=1, j<=30, j+= 2){
    if(j % 3, 5 == 0){
        console.log("FizzBizz");
    }
    else if(j % 5 == 0){
        console.log("Bizz");
    }
    else if(j % 3 == 0){
            console.log("fizz");
    }
    else {
        console.log(j)
    }
}